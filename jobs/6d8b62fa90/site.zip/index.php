<?php
session_start();
$uploadDir = __DIR__ . "/uploads/";
if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);

$message = "";
$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_FILES["file"])) {
    $f = $_FILES["file"];
    if ($f["error"] !== UPLOAD_ERR_OK) {
        $error = "Upload failed. Please try again.";
    } elseif ($f["size"] > 100 * 1024 * 1024) {
        $error = "Maximum file size is 100 MB.";
    } else {
        $original = basename($f["name"]);
        $safe = preg_replace('/[^A-Za-z0-9._ -]/', '_', $original);
        $safe = trim($safe, ". ");
        if ($safe === "") $safe = "file";
        $ext = pathinfo($safe, PATHINFO_EXTENSION);
        $base = pathinfo($safe, PATHINFO_FILENAME);
        $targetName = $safe;
        $i = 1;
        while (file_exists($uploadDir.$targetName)) {
            $targetName = $base . "_" . $i++ . ($ext ? ".".$ext : "");
        }
        if (move_uploaded_file($f["tmp_name"], $uploadDir.$targetName)) {
            $message = "File uploaded successfully. Share link is ready.";
        } else {
            $error = "Could not save the uploaded file.";
        }
    }
}

if (isset($_GET["delete"])) {
    $name = basename($_GET["delete"]);
    $path = $uploadDir.$name;
    if (is_file($path)) {
        unlink($path);
        header("Location: index.php?deleted=1");
        exit;
    }
}
if (isset($_GET["deleted"])) $message = "File deleted.";

$scheme = (!empty($_SERVER["HTTPS"]) && $_SERVER["HTTPS"] !== "off") ? "https" : "http";
$baseUrl = $scheme . "://" . $_SERVER["HTTP_HOST"] . rtrim(dirname($_SERVER["SCRIPT_NAME"]), "/\\") . "/uploads/";

$items = [];
foreach (glob($uploadDir."*") as $path) {
    if (is_file($path)) {
        $items[] = ["name"=>basename($path),"size"=>filesize($path),"time"=>filemtime($path)];
    }
}
usort($items, fn($a,$b) => $b["time"] <=> $a["time"]);
$total = array_sum(array_column($items, "size"));

function humanSize($bytes) {
    $units=["B","KB","MB","GB"]; $i=0;
    while($bytes>=1024 && $i<3){$bytes/=1024;$i++;}
    return round($bytes,2)." ".$units[$i];
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>MEDO MEDIA FIRE — File Hosting</title>
<style>
:root{--red:#ff1744;--blue:#1769ff;--bg:#070a12;--card:#0d1220;--line:#202b43;--text:#f7f9ff;--muted:#9ca8c0}
*{box-sizing:border-box}body{margin:0;font-family:Inter,system-ui,Arial;background:radial-gradient(circle at 10% 0%,#21101a,transparent 32%),radial-gradient(circle at 90% 10%,#0b1c48,transparent 34%),var(--bg);color:var(--text);min-height:100vh}
body:before{content:"";position:fixed;inset:0;pointer-events:none;background:linear-gradient(115deg,transparent 0 47%,rgba(255,23,68,.025) 50%,transparent 53%),linear-gradient(25deg,transparent 0 47%,rgba(23,105,255,.025) 50%,transparent 53%);background-size:80px 80px}
nav{height:76px;border-bottom:1px solid var(--line);background:rgba(7,10,18,.78);backdrop-filter:blur(18px);display:flex;align-items:center;justify-content:space-between;padding:0 6%;position:sticky;top:0;z-index:5}
.logo{font-weight:900;font-size:22px;letter-spacing:.8px}.logo span{color:var(--red)}.logo b{color:var(--blue)}.navbtn{border:1px solid #30405e;background:#111a2b;color:white;padding:10px 17px;border-radius:12px}
.wrap{width:min(1120px,92%);margin:auto}.hero{text-align:center;padding:70px 0 35px}.badge{display:inline-block;padding:8px 13px;border:1px solid #293955;border-radius:999px;background:#0d1627;color:#cbd7ed;font-size:13px}
.hero h1{font-size:clamp(38px,7vw,72px);line-height:1;margin:18px 0 15px;background:linear-gradient(90deg,#fff,var(--blue),var(--red));-webkit-background-clip:text;color:transparent}.hero p{color:var(--muted);font-size:17px}
.upload{margin:30px auto;padding:30px;border:1px solid #263654;border-radius:25px;background:linear-gradient(145deg,rgba(20,28,47,.92),rgba(10,14,25,.92));box-shadow:0 20px 70px #0007;max-width:850px}
.drop{border:2px dashed #354a70;border-radius:20px;padding:45px 20px;text-align:center}.drop:hover{border-color:var(--blue);background:#12203b66}.icon{font-size:45px}.drop h2{margin:10px 0}.drop p{color:var(--muted)}
input[type=file]{display:none}.choose{display:inline-block;cursor:pointer;padding:13px 24px;border-radius:12px;font-weight:800;background:linear-gradient(90deg,var(--blue),#426eff);box-shadow:0 8px 25px #1769ff44}
.submit{border:0;color:#fff;cursor:pointer;padding:13px 24px;border-radius:12px;font-weight:800;background:linear-gradient(90deg,var(--red),#ff4267);margin-left:8px}
.notice{margin:16px auto;max-width:850px;padding:13px 17px;border-radius:12px;background:#10233a;border:1px solid #244d75;color:#cfe6ff}.error{background:#381621;border-color:#733148;color:#ffd5df}
.stats{display:grid;grid-template-columns:repeat(3,1fr);gap:15px;margin:20px 0 28px}.stat{background:rgba(13,18,32,.85);border:1px solid var(--line);padding:20px;border-radius:17px}.stat small{color:var(--muted)}.stat strong{display:block;font-size:25px;margin-top:5px}
.panel{background:rgba(13,18,32,.9);border:1px solid var(--line);border-radius:22px;overflow:hidden;margin-bottom:60px}.panelhead{padding:20px 22px;border-bottom:1px solid var(--line);display:flex;gap:15px;justify-content:space-between;align-items:center}.search{background:#080d18;border:1px solid #273550;color:white;padding:11px 14px;border-radius:11px;width:230px}
.file{display:flex;align-items:center;gap:14px;padding:18px 22px;border-bottom:1px solid #182238}.file:last-child{border-bottom:0}.fileicon{width:45px;height:45px;border-radius:12px;display:grid;place-items:center;background:linear-gradient(145deg,#142d68,#40152a);font-size:21px}.fname{font-weight:700;word-break:break-all}.meta{font-size:12px;color:var(--muted);margin-top:4px}.grow{flex:1}.actions{display:flex;gap:8px;flex-wrap:wrap}
.btn{display:inline-block;text-decoration:none;color:white;border:1px solid #2b3c5c;background:#121c2e;padding:9px 12px;border-radius:10px;font-size:13px;cursor:pointer}.download{background:linear-gradient(90deg,var(--blue),#315eff);border:0}.share{background:linear-gradient(90deg,#087fbd,#1769ff);border:0}.del{color:#ff7891}
.empty{padding:45px;text-align:center;color:var(--muted)}footer{text-align:center;color:#6f7d97;padding:25px;border-top:1px solid #182238;font-size:13px}
.toast{position:fixed;left:50%;bottom:25px;transform:translateX(-50%) translateY(80px);background:#101b30;border:1px solid #315079;padding:13px 20px;border-radius:12px;opacity:0;transition:.3s;z-index:20;box-shadow:0 15px 40px #0008}.toast.show{opacity:1;transform:translateX(-50%) translateY(0)}
@media(max-width:650px){nav{padding:0 4%}.navbtn{display:none}.hero{padding-top:45px}.stats{grid-template-columns:1fr}.panelhead{align-items:stretch;flex-direction:column}.search{width:100%}.file{align-items:flex-start}.actions{flex-direction:column}.actions .btn{text-align:center}.submit{margin:10px 0 0;width:100%}.choose{display:block}}
</style>
</head>
<body>
<nav><div class="logo">MEDO <span>MEDIA</span>FIRE<b></b></div><div class="navbtn">⚡ FAST • SIMPLE • SHARE</div></nav>
<main class="wrap">
<section class="hero"><span class="badge">☁️ PERSONAL FILE HOSTING</span><h1>UPLOAD STORE SHARE</h1><p>Upload your file and instantly get a public link to send to anyone.</p></section>
<?php if($message): ?><div class="notice">✓ <?=htmlspecialchars($message)?></div><?php endif; ?>
<?php if($error): ?><div class="notice error">⚠ <?=htmlspecialchars($error)?></div><?php endif; ?>
<section class="upload"><form method="post" enctype="multipart/form-data"><div class="drop"><div class="icon">☁️</div><h2>Drop your file here</h2><p>Maximum 100 MB per file</p><label class="choose">Choose File<input id="file" type="file" name="file" required></label><button class="submit" type="submit">UPLOAD NOW</button><p id="picked">No file selected</p></div></form></section>
<section class="stats"><div class="stat"><small>FILES</small><strong><?=count($items)?></strong></div><div class="stat"><small>USED STORAGE</small><strong><?=humanSize($total)?></strong></div><div class="stat"><small>MAX FILE</small><strong>100 MB</strong></div></section>
<section class="panel"><div class="panelhead"><strong>My Files</strong><input class="search" id="search" placeholder="Search files..."></div><div id="list">
<?php if(!$items): ?><div class="empty">No files uploaded yet.<br>Upload your first file above.</div><?php endif; ?>
<?php foreach($items as $f):
$url=$baseUrl.rawurlencode($f["name"]); ?>
<div class="file" data-name="<?=htmlspecialchars(strtolower($f["name"]))?>">
<div class="fileicon">📄</div><div class="grow"><div class="fname"><?=htmlspecialchars($f["name"])?></div><div class="meta"><?=humanSize($f["size"])?> • <?=date("M d, Y H:i",$f["time"])?></div></div>
<div class="actions">
<a class="btn download" href="uploads/<?=rawurlencode($f["name"])?>" download>Download</a>
<button class="btn share" data-url="<?=htmlspecialchars($url,ENT_QUOTES)?>" data-name="<?=htmlspecialchars($f["name"],ENT_QUOTES)?>" onclick="shareFile(this)">🔗 Share</button>
<button class="btn" data-url="<?=htmlspecialchars($url,ENT_QUOTES)?>" onclick="copyLink(this)">Copy Link</button>
<a class="btn" href="uploads/<?=rawurlencode($f["name"])?>" target="_blank">Open</a>
<a class="btn del" href="?delete=<?=rawurlencode($f["name"])?>" onclick="return confirm('Delete this file?')">Delete</a>
</div></div>
<?php endforeach; ?></div></section></main>
<div class="toast" id="toast"></div><footer>MEDIA FIRE DEVELOP BY MEDO STUDIOS</footer>
<script>
const file=document.getElementById('file'),picked=document.getElementById('picked');
file.addEventListener('change',()=>picked.textContent=file.files[0]?file.files[0].name:"No file selected");
document.getElementById('search').addEventListener('input',e=>{const q=e.target.value.toLowerCase();document.querySelectorAll('.file').forEach(x=>x.style.display=x.dataset.name.includes(q)?'flex':'none')});
function toast(t){let x=document.getElementById('toast');x.textContent=t;x.classList.add('show');setTimeout(()=>x.classList.remove('show'),2200)}
async function copyLink(btn){const url=btn.dataset.url;try{await navigator.clipboard.writeText(url);toast('✓ Link copied!')}catch(e){prompt('Copy this link:',url)}}
async function shareFile(btn){
 const url=btn.dataset.url,name=btn.dataset.name;
 if(navigator.share){try{await navigator.share({title:name,text:'Download '+name,url:url})}catch(e){}}
 else {await copyLink(btn);toast('✓ Share link copied!')}
}
</script>
</body></html>