RAHUL X CLOUD v2 - FILE HOSTING

FEATURES
- PHP file upload
- Public direct file URL
- Copy Link button
- Share button using device share sheet when supported
- Download / Open / Delete
- Search
- Red + blue responsive HD UI
- 100 MB per-file limit

INSTALL
1. Upload index.php and the uploads folder to PHP hosting.
2. Make sure uploads/ is writable by PHP.
3. Open your domain.
4. Upload a file.
5. Use Copy Link or Share. The generated link is based on your live domain.

IMPORTANT
This is a MediaFire-style file-hosting project, not the actual MediaFire service.
For production use, add login/authentication, CSRF protection, MIME validation,
rate limits, storage quotas, file scanning, and stronger access controls.
