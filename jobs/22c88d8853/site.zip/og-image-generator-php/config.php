<?php
declare(strict_types=1);

/* ===== SITE SETTINGS (yahan se sab kuch change karein) ===== */
const SITE_TITLE     = 'SYCOPATHAN • OG Image Generator';
const SITE_NAME      = 'SYCOPATHAN';
const LOGO_URL       = 'https://i.ibb.co/FbRH2Zgt/1781342101457.jpg';
const HERO_TITLE     = 'OG Image Generator';
const HERO_TEXT      = 'Design a 1200×630 Open Graph / social preview image and download it as PNG.';
const COPYRIGHT_LINE = '© 2026 - HALAKU WOLF INTELLIGENCE. All rights reserved.';
const DEVELOPER_LINE = 'Dev: SYCOPATHAN';

/* ===== FORM KE DEFAULT VALUES ===== */
const DEFAULT_TITLE    = 'SYCOPATHAN TOOL';
const DEFAULT_SUBTITLE = 'Premium browser tools for creators & developers';
const DEFAULT_BADGE    = 'OFFICIAL TOOL COLLECTION';
const DEFAULT_BRAND    = 'SYCOPATHAN';
const DEFAULT_C1       = '#0b1020';
const DEFAULT_C2       = '#6b4e0d';
const DEFAULT_ACCENT   = '#f4d27a';
const DEFAULT_TEXT     = '#ffffff';

/* HTML escape helper */
function e(string $s): string
{
    return htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}
