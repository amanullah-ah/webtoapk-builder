<?php
declare(strict_types=1);

/*
 * OG templates (34).
 * tpl(name, startColor, endColor, accent, textColor, decoration 0-12, align l/c/r, frame 0-3, extras)
 * extras: f=font, w=weight, ul=underline bar, up=uppercase, it=italic,
 *         st=outline text, sh=[color, blur, offsetX, offsetY], card=text card
 */
function tpl(string $n, string $c1, string $c2, string $ac, string $tx, int $d, string $al, int $fr, array $x = []): array
{
    return ['n' => $n, 'c1' => $c1, 'c2' => $c2, 'ac' => $ac, 'tx' => $tx, 'd' => $d, 'al' => $al, 'fr' => $fr, 'x' => (object) $x];
}

return [
    tpl('Gold Royal',     '#0b1020', '#6b4e0d', '#f4d27a', '#ffffff', 0,  'l', 1),
    tpl('Midnight Blue',  '#050b1f', '#1d4ed8', '#7dd3fc', '#ffffff', 3,  'l', 0),
    tpl('Neon Cyber',     '#0a0014', '#4c1d95', '#22e6ff', '#ffffff', 2,  'c', 1),
    tpl('Sunset Glow',    '#7c1d6f', '#f97316', '#fde68a', '#ffffff', 0,  'c', 0),
    tpl('Emerald',        '#022c22', '#047857', '#6ee7b7', '#ffffff', 4,  'l', 3),
    tpl('Crimson',        '#1a0505', '#991b1b', '#fca5a5', '#ffffff', 1,  'l', 2),
    tpl('Purple Haze',    '#1e0b3a', '#a21caf', '#f0abfc', '#ffffff', 3,  'c', 0),
    tpl('Clean Light',    '#ffffff', '#e2e8f0', '#2563eb', '#0f172a', 2,  'l', 3),
    tpl('Rose Gold',      '#2a1216', '#b76e79', '#ffe4e1', '#ffffff', 0,  'c', 1),
    tpl('Mono Dark',      '#000000', '#2b2b2b', '#ffffff', '#ffffff', 4,  'l', 0),
    tpl('Retro Yellow',   '#facc15', '#f97316', '#111827', '#111827', 1,  'c', 2),
    tpl('Ice Mint',       '#ecfeff', '#99f6e4', '#0f766e', '#134e4a', 3,  'c', 0),
    tpl('Aurora',         '#021b2b', '#0f766e', '#a7f3d0', '#ffffff', 9,  'c', 0),
    tpl('Paper Ink',      '#f5f0e6', '#e8dcc2', '#b91c1c', '#1c1917', 12, 'l', 2),
    tpl('Cyber Grid',     '#000000', '#0b132b', '#00ff9c', '#e6fff5', 7,  'l', 1),
    tpl('Pastel Pop',     '#fde2e4', '#bde0fe', '#7c3aed', '#312e81', 11, 'c', 0),
    tpl('Volcano',        '#1c0a00', '#ea580c', '#fcd34d', '#ffffff', 6,  'l', 3),
    tpl('Deep Space',     '#02010a', '#312e81', '#c4b5fd', '#ffffff', 2,  'c', 1),
    tpl('Forest',         '#0f2a1d', '#3f6212', '#d9f99d', '#ffffff', 8,  'l', 0),
    tpl('Candy',          '#ff5f9e', '#8b5cf6', '#fff1f2', '#ffffff', 10, 'c', 0),
    tpl('Steel',          '#0f172a', '#475569', '#38bdf8', '#ffffff', 5,  'l', 2),
    tpl('Sand Dune',      '#fef3c7', '#f59e0b', '#78350f', '#451a03', 8,  'c', 3),
    tpl('Newspaper',      '#f4f1ea', '#e7e2d6', '#111111', '#111111', 12, 'l', 1, ['f' => 'Georgia', 'w' => 700, 'ul' => 1]),
    tpl('Impact Poster',  '#0a0a0a', '#1f1f1f', '#ffdd00', '#ffffff', 1,  'l', 3, ['f' => 'Impact', 'w' => 400, 'up' => 1]),
    tpl('Typewriter',     '#1b1b1b', '#2a2a2a', '#9ae6b4', '#e2e8f0', 12, 'l', 0, ['f' => 'Courier New', 'w' => 700]),
    tpl('Elegant Script', '#1a1022', '#3b1f4a', '#f5d0fe', '#fdf4ff', 3,  'c', 1, ['f' => 'Georgia', 'it' => 1, 'w' => 400, 'ul' => 1]),
    tpl('Outline Bold',   '#0f172a', '#1e3a8a', '#fbbf24', '#fbbf24', 7,  'c', 0, ['f' => 'Impact', 'st' => 1, 'up' => 1, 'w' => 400]),
    tpl('Glow Neon',      '#05010f', '#1b0536', '#ff2e97', '#ffffff', 9,  'c', 0, ['f' => 'Trebuchet MS', 'w' => 900, 'up' => 1, 'sh' => ['#ff2e97', 40, 0, 0]]),
    tpl('Card Panel',     '#0ea5e9', '#6366f1', '#ffffff', '#ffffff', 10, 'l', 0, ['card' => 1]),
    tpl('Right Aligned',  '#1c1917', '#44403c', '#fb923c', '#fafaf9', 5,  'r', 2, ['f' => 'Verdana', 'w' => 700]),
    tpl('Hard Shadow',    '#fde047', '#fb7185', '#111111', '#ffffff', 6,  'l', 0, ['f' => 'Impact', 'w' => 400, 'up' => 1, 'sh' => ['#111111', 0, 8, 8]]),
    tpl('Minimal Mono',   '#fafafa', '#f1f5f9', '#0f172a', '#0f172a', 11, 'l', 3, ['f' => 'Courier New', 'w' => 700, 'ul' => 1]),
    tpl('Royal Serif',    '#1e1b4b', '#581c87', '#fcd34d', '#fef3c7', 0,  'c', 1, ['f' => 'Times New Roman', 'w' => 700, 'up' => 1, 'ul' => 1]),
    tpl('Bold Italic',    '#3b0764', '#db2777', '#fde68a', '#ffffff', 1,  'r', 3, ['f' => 'Arial', 'w' => 900, 'it' => 1, 'up' => 1]),
];
