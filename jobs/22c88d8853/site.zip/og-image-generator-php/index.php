<?php
declare(strict_types=1);
require __DIR__ . '/config.php';
$templates = require __DIR__ . '/templates.php';

header('X-Frame-Options: SAMEORIGIN');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: strict-origin-when-cross-origin');

$json = json_encode($templates, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="theme-color" content="#a491d4">
<title><?= e(SITE_TITLE) ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link rel="stylesheet" href="style.css">
</head>
<body>

<div class="wrap">
  <div class="brand">
    <img src="<?= e(LOGO_URL) ?>" alt="" onerror="this.style.display='none'">
    <div>
      <b id="hb"><?= e(SITE_NAME) ?></b>
    </div>
  </div>

  <section class="hero">
    <h1><?= e(HERO_TITLE) ?></h1>
    <p><?= e(HERO_TEXT) ?></p>
  </section>

  <section class="panel">
    <div class="lbl"><i class="fa-solid fa-layer-group"></i> Select Template</div>
    <div class="field">
      <select id="tplSelect" onchange="pick(this.value)">
<?php foreach ($templates as $i => $t): ?>
        <option value="<?= (int) $i ?>"><?= e($t['n']) ?></option>
<?php endforeach; ?>
      </select>
    </div>
  </section>

  <section class="panel">
    <div class="lbl"><i class="fa-solid fa-pen-to-square"></i> Customize Content</div>
    <div class="grid">
      <div class="field">
        <label>Title</label>
        <textarea id="title"><?= e(DEFAULT_TITLE) ?></textarea>
      </div>
      <div class="field">
        <label>Subtitle</label>
        <input id="sub" value="<?= e(DEFAULT_SUBTITLE) ?>">
      </div>
      <div class="field">
        <label>Badge</label>
        <input id="badge" value="<?= e(DEFAULT_BADGE) ?>">
      </div>
      <div class="field">
        <label>Brand Name</label>
        <input id="brand" value="<?= e(DEFAULT_BRAND) ?>" maxlength="30">
      </div>
      <div class="field">
        <label>Start Color</label>
        <input id="c1" type="color" value="<?= e(DEFAULT_C1) ?>">
      </div>
      <div class="field">
        <label>End Color</label>
        <input id="c2" type="color" value="<?= e(DEFAULT_C2) ?>">
      </div>
      <div class="field">
        <label>Accent</label>
        <input id="ac" type="color" value="<?= e(DEFAULT_ACCENT) ?>">
      </div>
      <div class="field">
        <label>Text Color</label>
        <input id="tx" type="color" value="<?= e(DEFAULT_TEXT) ?>">
      </div>
    </div>
    <div class="toolbar">
      <button class="btn pri" onclick="render()"><i class="fa-solid fa-wand-magic-sparkles"></i> Generate Image</button>
      <button class="btn" onclick="save()"><i class="fa-solid fa-download"></i> Download PNG</button>
    </div>
  </section>

  <section class="panel" style="padding:12px;">
    <div class="preview-wrap">
      <canvas id="cv" class="preview" width="1200" height="630"></canvas>
    </div>
  </section>

  <div class="foot">
    <?= e(COPYRIGHT_LINE) ?><br><?= e(DEVELOPER_LINE) ?>
  </div>
</div>

<script>window.OG_TEMPLATES = <?= $json ?>;</script>
<script src="script.js"></script>
</body>
</html>
