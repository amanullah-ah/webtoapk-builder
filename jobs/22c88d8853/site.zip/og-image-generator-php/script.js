const c=document.getElementById('cv'),x=c.getContext('2d'),$=i=>document.getElementById(i);let D=0,AL='l',FR=0,E={};

/* Templates PHP (templates.php) se aate hain */
const T=(window.OG_TEMPLATES||[]).map(t=>({n:t.n,c1:t.c1,c2:t.c2,ac:t.ac,tx:t.tx,d:t.d,al:t.al,fr:t.fr,x:t.x||{}}));

function pick(i){
  const t=T[i];
  ['c1','c2','ac','tx'].forEach(k=>$(k).value=t[k]);
  D=t.d; AL=t.al; FR=t.fr; E=t.x;
  render();
}

document.querySelectorAll('input,textarea').forEach(e=>e.addEventListener('input',render));

function deco(ac){x.save();x.fillStyle=ac;x.strokeStyle=ac;const P=(a,l)=>{x.beginPath();a.forEach((p,i)=>i?x.lineTo(p[0],p[1]):x.moveTo(p[0],p[1]));x.fill()};
if(D==0){x.globalAlpha=.08;for(let i=0;i<15;i++){x.beginPath();x.arc(70+i*90,80+(i%5)*120,40+(i%3)*30,0,7);x.fill()}}
else if(D==1){x.globalAlpha=.09;x.lineWidth=26;for(let i=-4;i<18;i++){x.beginPath();x.moveTo(i*90+400,0);x.lineTo(i*90,630);x.stroke()}}
else if(D==2){x.globalAlpha=.18;for(let a=30;a<1200;a+=48)for(let b=30;b<630;b+=48){x.beginPath();x.arc(a,b,3,0,7);x.fill()}}
else if(D==3){x.globalAlpha=.12;x.lineWidth=3;for(let r=90;r<760;r+=80){x.beginPath();x.arc(1040,120,r,0,7);x.stroke()}}
else if(D==4){x.globalAlpha=.09;for(let i=0;i<14;i++){const h=60+(i*53%260);x.fillRect(i*90+10,630-h,60,h)}}
else if(D==5){x.globalAlpha=.1;P([[760,0],[1200,0],[1200,630],[520,630]])}
else if(D==6){x.globalAlpha=.16;P([[1200,0],[1200,280],[920,0]]);P([[0,630],[0,380],[280,630]])}
else if(D==7){x.globalAlpha=.12;x.lineWidth=2;for(let a=40;a<1200;a+=80)for(let b=40;b<630;b+=80)x.strokeRect(a,b,56,56)}
else if(D==8){x.globalAlpha=.12;for(let k=0;k<4;k++){x.beginPath();x.moveTo(0,630);for(let a=0;a<=1200;a+=20)x.lineTo(a,470+k*45+Math.sin(a/70+k)*18);x.lineTo(1200,630);x.fill()}}
else if(D==9){x.globalAlpha=.4;[[900,130,380],[200,560,320]].forEach(p=>{const r=x.createRadialGradient(p[0],p[1],0,p[0],p[1],p[2]);r.addColorStop(0,ac);r.addColorStop(1,ac+'00');x.fillStyle=r;x.fillRect(0,0,1200,630)})}
else if(D==10){x.globalAlpha=.16;x.lineWidth=40;x.beginPath();x.arc(150,540,300,0,7);x.stroke();x.beginPath();x.arc(1080,90,170,0,7);x.stroke()}
else if(D==11){x.globalAlpha=.2;x.lineWidth=6;for(let a=60;a<1200;a+=110)for(let b=60;b<630;b+=110){x.beginPath();x.moveTo(a-12,b);x.lineTo(a+12,b);x.moveTo(a,b-12);x.lineTo(a,b+12);x.stroke()}}
else{x.globalAlpha=.12;x.lineWidth=2;for(let b=40;b<630;b+=40){x.beginPath();x.moveTo(0,b);x.lineTo(1200,b);x.stroke()}}
x.restore()}
function frame(ac){x.save();x.fillStyle=ac;x.strokeStyle=ac;if(FR==1){x.globalAlpha=.6;x.lineWidth=4;x.strokeRect(24,24,1152,582)}else if(FR==2)x.fillRect(0,0,22,630);else if(FR==3)x.fillRect(0,0,1200,14);x.restore()}
function lines(t,max){return t.split('\n').flatMap(p=>{const out=[];let line='';for(const w of p.split(/\s+/).filter(Boolean)){const test=line?line+' '+w:w;if(x.measureText(test).width>max&&line){out.push(line);line=w}else line=test}out.push(line);return out})}
function render(){const B=$('brand').value;$('hb').textContent=B||' ';const g=x.createLinearGradient(0,0,1200,630);g.addColorStop(0,$('c1').value);g.addColorStop(1,$('c2').value);x.fillStyle=g;x.fillRect(0,0,1200,630);
const ac=$('ac').value,tx=$('tx').value,C=AL=='c',R=AL=='r',X=C?600:R?1130:70,M=C?1000:1060,F=E.f?`"${E.f}",sans-serif`:'Inter,Arial',I=E.it?'italic ':'',tt=$('title').value,TF=s=>`${I}${E.w||950} ${s}px ${F}`;deco(ac);frame(ac);x.textAlign=C?'center':R?'right':'left';
x.fillStyle=ac;x.font=`900 19px ${F}`;x.fillText($('badge').value,X,91);
let s=96,L;for(;s>=36;s-=4){x.font=TF(s);L=lines(E.up?tt.toUpperCase():tt,M);if(L.length*s*1.12<=250&&L.every(l=>x.measureText(l).width<=M))break}
x.font=TF(s);const ye=150+s+(L.length-1)*s*1.12,ul=E.ul?28:0;
if(E.card){x.save();x.globalAlpha=.16;x.fillStyle=ac;x.beginPath();x.roundRect(40,120,1120,ye+36-120,28);x.fill();x.restore()}
x.save();if(E.sh){x.shadowColor=E.sh[0];x.shadowBlur=E.sh[1];x.shadowOffsetX=E.sh[2]||0;x.shadowOffsetY=E.sh[3]||0}
x.fillStyle=tx;x.strokeStyle=tx;x.lineWidth=s/24;x.lineJoin='round';L.forEach((l,i)=>{const y=150+s+i*s*1.12;E.st?x.strokeText(l,X,y):x.fillText(l,X,y)});x.restore();
if(E.ul){x.fillStyle=ac;x.fillRect(C?530:R?X-140:X,ye+20,140,8)}
let q=32,S;for(;q>20;q-=2){x.font=`500 ${q}px ${F}`;S=lines($('sub').value,M);if(S.length<=2)break}
x.font=`${I}500 ${q}px ${F}`;x.fillStyle=tx;x.globalAlpha=.78;S.forEach((l,i)=>x.fillText(l,X,ye+34+ul+q+i*q*1.3));x.globalAlpha=1;
x.fillStyle=ac;x.font=`900 28px ${F}`;x.textAlign=C?'center':R?'left':'right';x.fillText(B,C?600:R?70:1130,575);x.textAlign='left'}
function save(){c.toBlob(b=>{const a=document.createElement('a');a.href=URL.createObjectURL(b);a.download='og-image-1200x630.png';a.click();URL.revokeObjectURL(a.href)},'image/png')}

// Initial Load
pick(0);
