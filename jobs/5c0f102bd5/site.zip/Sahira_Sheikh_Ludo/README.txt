SAHIRA SHEIKH LUDO — FULL SOURCE PROJECT

Included:
- index.html: complete single-page HTML/CSS/JavaScript game.
- Offline mode: 2–4 local players on one device.
- Online mode: create a room and share the room code; another player joins from their device.
- Owner credit: Sahira Sheikh, Hyderabad, Pakistan.

HOW TO RUN
1. Extract this ZIP.
2. Open index.html in a modern browser (Chrome recommended).
3. Offline: select player count and press Start Offline Game.
4. Online: both players need internet. One player selects Online > Create Online Room and shares the room code. The other selects Online, enters the code and presses Join Room.

ONLINE NOTE
Online connection uses PeerJS's public cloud signaling service and direct browser peer-to-peer networking. It requires internet access and the PeerJS CDN to load. Public free signaling is best-effort; for a commercial/public release, use your own maintained signaling server and test on the target networks.

This is a browser source project, not an APK. To publish as an Android app, wrap it with Capacitor or another WebView packaging tool.
